class GameOptions:
    def __init__(self, player_count=2, columns=4, rows=4):
        self.player_count = player_count
        self.columns = columns
        self.rows = rows
