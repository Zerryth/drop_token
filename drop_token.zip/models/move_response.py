class MoveResponse:
    def __init__(self, move: str):
        self.move = move
